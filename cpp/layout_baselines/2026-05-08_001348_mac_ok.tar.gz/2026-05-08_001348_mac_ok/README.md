# Baseline QML 2026-05-08 00:13:48 macOS

Snapshot dos QMLs ativos aprovados visualmente no macOS.

Contexto:

- Commit base: `155b615`
- Plataforma validada: macOS
- App: `cpp/build/nmr5_qml`
- Layout: calculadoras na esquerda, tabelas na direita, largura compacta.
- Observacao: a interface foi considerada boa apos o ajuste de proporcao,
  alinhamento e largura da area de calculadoras.

Uso:

- Comparar este snapshot antes de qualquer ajuste visual amplo.
- Nao alterar este diretorio.
- Se um novo layout for aprovado, criar outro snapshot com novo timestamp.
